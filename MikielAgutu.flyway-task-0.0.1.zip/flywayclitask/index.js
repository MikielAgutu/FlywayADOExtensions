"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tasks = require("azure-pipelines-task-lib/task");
const flywayCliRunner_1 = __importDefault(require("../lib/flywayCliRunner"));
async function run() {
    try {
        let x = (0, flywayCliRunner_1.default)();
        let tool;
        const command = tasks.getInput('command', true);
        if (!command) {
            return tasks.setResult(tasks.TaskResult.Failed, "Command is required");
        }
        const workingDirectory = tasks.getPathInput('workingDirectory', true);
        const dbUrl = tasks.getInput('url', true);
        const dbUser = tasks.getInput('user', false);
        const dbPassword = tasks.getInput('password', false);
        const commandOptions = tasks.getInput('commandOptions', false);
        console.log("Flyway command: " + command);
        console.log("Working directory: " + workingDirectory);
        console.log("Database jdbc url: " + dbUrl);
        console.log("Database jdbc user: " + dbUser);
        console.log("Command options: " + commandOptions);
        let cmdPath = tasks.which("flyway", true);
        console.log('Flyway found at path: ' + cmdPath);
        let args = [];
        args.push('-n');
        args.push('-color=always');
        args.push('-locations=filesystem:' + workingDirectory);
        args.push('-url=' + dbUrl);
        if (dbUser) {
            args.push('-user=' + dbUser);
        }
        if (dbPassword) {
            args.push('-password=' + dbPassword);
        }
        if (commandOptions) {
            let cO = commandOptions.split(' ');
            cO.forEach(v => args.push(v));
        }
        args.push(command);
        tool = tasks.tool(cmdPath).arg(args);
        await tool.execAsync();
        tasks.setResult(tasks.TaskResult.Succeeded, "");
    }
    catch (err) {
        tasks.setResult(tasks.TaskResult.Failed, err.message);
    }
}
run();
